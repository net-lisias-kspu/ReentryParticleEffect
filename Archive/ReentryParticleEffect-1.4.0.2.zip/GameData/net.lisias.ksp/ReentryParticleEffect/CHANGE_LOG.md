# Reentry Particle Effect /L Unleashed :: Change Log

* 2021-1027: 1.4.0.2 (LisiasT) for KSP >= 1.4.
	+ Updating to KSPe.UI v2.4
* 2021-0413: 1.4.0.1 (LisiasT) for KSP >= 1.4.
	+ Making the thing compatible from KSP 1.4 to the latest
	+ Adding KSPe installment checks facilities
	+ Moving it into `net.lisias.ksp` hierarchy
* 2019-0212: 1.4.0 (pizzaoverhead) for KSP 1.6.
	+ Recompiled and updated for KSP 1.6.
	+ Reduced the scale of the plasma trail.
* 2018-0824: 1.3 (pizzaoverhead) for KSP 1.4.5
	+ Recompiled and updated for KSP 1.4 compatibility.
* 2016-1024: 1.2a (pizzaoverhead) for KSP 1.2
	+ Recompiled for KSP 1.2.
* 2016-0704: 1.1 (pizzaoverhead) for KSP 1.1.3
	+ Changed re-entry effects to activate only during harsh aerobraking.
* 2016-0703: 1.0 (pizzaoverhead) for KSP 1.1.3
	+ A mod for KSP that activates an unused stock particle effect for re-entry, featuring a plasma trail and sparks.

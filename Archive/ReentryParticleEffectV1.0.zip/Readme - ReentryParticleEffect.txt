-------------------------------------------------------------
 Reentry Particle Effect
 Author:    pizzaoverhead
 Version:   1.0
 Released:  2016-07-03
 KSP:       v1.1.3

 Thread:    http://forum.kerbalspaceprogram.com/index.php?/topic/143040-113-reentry-particle-effect/
 Licence:   GNU v2, http://www.gnu.org/licenses/gpl-2.0.html
 Source:    https://github.com/pizzaoverhead/ReentryParticleEffect
-------------------------------------------------------------

This mod activates an unused stock particle effect for reentry, featuring a plasma trail and sparks. 


Installation
------------
Extract the zip to the root KSP folder, merging with the GameData folder.


Uninstallation
--------------
Delete the ReentryParticleEffect folder inside GameData.


Version history
---------------
1.0 (2014-11-29)
- Initial release.
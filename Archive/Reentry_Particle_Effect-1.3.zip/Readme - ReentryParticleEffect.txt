-------------------------------------------------------------
 Reentry Particle Effect
 Author:    pizzaoverhead
 Version:   1.3
 Released:  2018-08-24
 KSP:       v1.4.3

 Thread:    http://forum.kerbalspaceprogram.com/index.php?/topic/143040-113-reentry-particle-effect/
 Licence:   GNU v2, http://www.gnu.org/licenses/gpl-2.0.html
 Source:    https://github.com/pizzaoverhead/ReentryParticleEffect
-------------------------------------------------------------

This mod activates an unused stock particle effect for re-entry, featuring a plasma trail and sparks. 


Installation
------------
Extract the zip to the root KSP folder, merging with the GameData folder.


Uninstallation
--------------
Delete the ReentryParticleEffect folder inside GameData.


Version history
---------------
1.3 (2018-08-24)
- Recompiled and updated for KSP 1.4 compatibility.

1.2 (2016-10-24)
- Recompiled for KSP 1.2 compatibility.

1.1 (2016-04-07)
- Changed re-entry effects to activate only during harsh aerobraking.

1.0 (2016-04-06)
- Initial release.